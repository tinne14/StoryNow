package com.tinne14.storyapp.ui.direpo

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import com.tinne14.storyapp.ui.pref.LoginPreference

object Injection {
    fun provideRepository(dataStore: DataStore<Preferences>): Repository {
        val preference = LoginPreference.getInstance(dataStore)
        return Repository.getInstance(preference)
    }
}