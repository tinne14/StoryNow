package com.tinne14.storyapp.ui.adapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.tinne14.storyapp.data.ListStoryItem
import com.tinne14.storyapp.databinding.ItemStoryBinding
import com.tinne14.storyapp.ui.activity.DetailActivity
import com.tinne14.storyapp.ui.activity.DetailActivity.Companion.EXTRA_ID

class StoryAdapter(private val listStory: List<ListStoryItem>) :
    RecyclerView.Adapter<StoryAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemStoryBinding) : RecyclerView.ViewHolder(
        binding.root
    )


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemBinding =
            ItemStoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(itemBinding)
    }

    override fun getItemCount() = listStory.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        Glide.with(holder.itemView)
            .load(listStory[position].photoUrl)
            .into(holder.binding.imgPhoto)

        holder.binding.apply {
            tvDeskripsi.text = listStory[position].description
            tvUsername.text = listStory[position].name
            tvDate.text = listStory[position].createdAt
        }

        holder.itemView.setOnClickListener {
            val bi = holder.binding
            val optionsCompat: ActivityOptionsCompat =
                ActivityOptionsCompat.makeSceneTransitionAnimation(
                    holder.itemView.context as Activity,
                    Pair(bi.imgPhoto, "photo"),
                    Pair(bi.tvUsername, "username"),
                    Pair(bi.tvDeskripsi, "description"),
                    Pair(bi.tvDate, "date")
                )

            val moveDetail = Intent(holder.itemView.context, DetailActivity::class.java)
            moveDetail.putExtra(EXTRA_ID, listStory[holder.adapterPosition].id)
            holder.itemView.context.startActivity(moveDetail, optionsCompat.toBundle())
        }
    }
}