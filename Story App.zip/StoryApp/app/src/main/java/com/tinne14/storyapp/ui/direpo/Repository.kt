package com.tinne14.storyapp.ui.direpo

import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import com.tinne14.storyapp.ui.pref.LoginPreference

class Repository private constructor(private val preference: LoginPreference) {

    fun getToken(): LiveData<String> {
        return preference.getToken().asLiveData()
    }

    fun getSesi(): LiveData<Boolean> {
        return preference.getSesi().asLiveData()
    }

    suspend fun saveToken(token: String) {
        preference.saveToken(token)
    }

    suspend fun logout() = preference.logout()

    companion object {
        @Volatile
        private var instance: Repository? = null
        fun getInstance(
            preference: LoginPreference
        ): Repository =
            instance ?: synchronized(this) {
                instance ?: Repository(preference)
            }.also { instance = it }
    }
}